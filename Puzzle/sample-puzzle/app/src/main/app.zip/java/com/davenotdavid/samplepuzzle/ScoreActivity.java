package com.davenotdavid.samplepuzzle;

import android.content.Context;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ScoreActivity extends AppCompatActivity {

    public static final java.lang.String SCORE_EXTRA = "SCORE";
    ArrayList<String> list;
    StableArrayAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score);
        ListView scoreList = (ListView) findViewById(R.id.list_score);
        if (Singleton.getInstance().getList() == null) {
            Singleton.getInstance().setList(new ArrayList<String>());
            Singleton.getInstance().getList().add("Puntuación: 18 | Nombre: Angelo");
            Singleton.getInstance().getList().add("Puntuación: 22 | Nombre: Pedro");
        }

        Bundle extras = getIntent().getExtras();

        if (extras != null) {
            final String newScore = extras.getString(SCORE_EXTRA);

            Singleton.getInstance().getList().add(newScore);
        }

        adapter = new StableArrayAdapter(this,
                android.R.layout.simple_list_item_1, Singleton.getInstance().getList());
        scoreList.setAdapter(adapter);
    }

    private class StableArrayAdapter extends ArrayAdapter<String> {

        HashMap<String, Integer> mIdMap;

        public StableArrayAdapter(Context context, int textViewResourceId,
                                  List<String> objects) {
            super(context, textViewResourceId, objects);
            mIdMap = new HashMap<String, Integer>();
            for (int i = 0; i < objects.size(); ++i) {
                mIdMap.put(objects.get(i), i);
            }
        }

        @Override
        public long getItemId(int position) {
            String item = getItem(position);
            return mIdMap.get(item);
        }

        @Override
        public boolean hasStableIds() {
            return true;
        }

    }
}
